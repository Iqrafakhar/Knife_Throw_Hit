using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnifeController : MonoBehaviour
{
    [SerializeField]
    private Vector2 throwForce;
    private bool isActive = true;
    private Rigidbody2D rb;
    private BoxCollider2D knifeCollider;
    public bool gameOver  = false;

    private void Awake()
    {

        rb = GetComponent<Rigidbody2D>();
        knifeCollider = GetComponent<BoxCollider2D>();

    }

    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.UpArrow) && isActive)
        {
            rb.AddForce(throwForce, ForceMode2D.Impulse);
            //to decrement the number of knives
            rb.gravityScale = 1;   
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(!isActive)
        {
            return;
        }
        isActive = false;

        if(collision.collider.tag == "Log")
        {
            rb.velocity = new Vector2(0,0);
            rb.bodyType = RigidbodyType2D.Kinematic;
            this.transform.SetParent(collision.collider.transform);
            //spawn knife
            knifeCollider.offset = new Vector2(knifeCollider.offset.x , -4.632806f);
            knifeCollider.size = new Vector2(knifeCollider.size.x, 10.74061f);

        }
        else if(collision.collider.tag == "Log")
        {
            rb.velocity = new Vector2(rb.velocity.x, -2);
        }

        if(collision.gameObject.CompareTag("Knife"))
		{
			gameOver = true;
		}
		else if(collision.gameObject.CompareTag("Knife"))
		{
			gameOver = true;	
			Debug.Log("Game Over");
            Destroy(gameObject);
		}
    
    }
    // Start is called before the first frame update
    /*void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }*/
}
