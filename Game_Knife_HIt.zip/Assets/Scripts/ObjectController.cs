using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectController : MonoBehaviour
{
    //weneed a reference to obstacle
    public GameObject Knife;
//spwan position f0r obstacle 
    private Vector3 spawnPos = new Vector3(0,-74,0);
//start variable time
    private float startDelay = 2;
//Repeat at every 2 sec variable
    private float repeatRate = 15;
//conneccting with player Controller
    private KnifeController KnifeControllerScript;
    // Start is called before the first frame update
    void Start()
    {
	KnifeControllerScript = GameObject.Find("Knife").GetComponent<KnifeController>();
	//spawning obstacle at specific time
        InvokeRepeating("SpawnKnife", startDelay, repeatRate);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void SpawnKnife()
    {
	if(KnifeControllerScript.gameOver == false)
	{
		//create prefab once again using instantiate method #spawnObtacle

		Instantiate(Knife,spawnPos , Knife.transform.rotation);
	}		
    }
    // Start is called before the first frame update
    /*void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }*/
}
